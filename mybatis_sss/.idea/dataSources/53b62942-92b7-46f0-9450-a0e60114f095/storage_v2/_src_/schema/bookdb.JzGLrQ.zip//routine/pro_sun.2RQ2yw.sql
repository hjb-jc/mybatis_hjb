create procedure pro_sun(IN p int)
  begin
declare x int;
set x = 0;
set @sun = 0;
repeat
set x =x + 1 ;
set @sun =@sun + x ;
until x >= p end repeat;
end;

